const contactsDiv = document.getElementById('contacts');
const searchInput = document.getElementById('search');
const loader = document.getElementById('loader');
const modal = document.getElementById('modal');
const modalBody = document.getElementById('modal-body');
const closeBtn = document.getElementById('close');

let allContacts = [];

async function fetchContacts() {
  try {
    loader.style.display = 'block';
    const res = await fetch('https://randomuser.me/api/?results=20');
    const data = await res.json();
    allContacts = data.results.sort((a, b) => a.name.first.localeCompare(b.name.first));
    displayContacts(allContacts);
  } catch (err) {
    contactsDiv.innerHTML = '<p style="color:red;">⚠️ Failed to load contacts. Please try again.</p>';
  } finally {
    loader.style.display = 'none';
  }
}

function displayContacts(contacts) {
  contactsDiv.innerHTML = '';
  contacts.forEach(user => {
    const card = document.createElement('div');
    card.className = 'contact-card';

    card.innerHTML = `
      <img src="${user.picture.thumbnail}" alt="Photo" />
      <div class="contact-info">
        <strong>${user.name.first} ${user.name.last}</strong><br>
        ${user.email}
      </div>
      <button class="view-btn">View</button>
    `;

    card.querySelector('.view-btn').addEventListener('click', () => {
      showModal(user);
    });

    contactsDiv.appendChild(card);
  });
}

searchInput.addEventListener('input', (e) => {
  const term = e.target.value.toLowerCase();
  const filtered = allContacts.filter(user =>
    `${user.name.first} ${user.name.last}`.toLowerCase().includes(term)
  );
  displayContacts(filtered);
});

function showModal(user) {
  modalBody.innerHTML = `
    <h2>${user.name.first} ${user.name.last}</h2>
    <img src="${user.picture.large}" style="border-radius:50%; margin:10px auto; display:block;" />
    <p><strong>Email:</strong> ${user.email}</p>
    <p><strong>Phone:</strong> ${user.phone}</p>
    <p><strong>Location:</strong> ${user.location.city}, ${user.location.country}</p>
  `;
  modal.classList.remove('hidden');
}

closeBtn.addEventListener('click', () => {
  modal.classList.add('hidden');
});

window.addEventListener('click', (e) => {
  if (e.target === modal) modal.classList.add('hidden');
});

// Initial call
fetchContacts();